module.exports = () => {
    let scene, debugCube;

    let model_importer, THREE
    return {
        THREE,
        scene,
        debugCube,
        model_importer,
        EffectComposer,
        SAOPass,
        composer
    }
}